const express = require("express");
const fs = require('fs');
const app = express();

// Add these lines to support JSON body parsing
const bodyParser = require('body-parser');
app.use(bodyParser.json());

app.use(express.static('public'));

app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'none'; img-src 'self'; script-src 'self'; style-src 'self'; font-src 'self';"
  );
  next();
});

app.get('/api/courses', (req, res) => {
  fs.readFile('./database/courses.json', 'utf8', (error, data) => {
    if (error) {
      console.error('Error reading courses.json:', error);
      res.status(500).send('Error reading courses.json');
    } else {
      res.json(JSON.parse(data));
    }
  });
});

app.post('/users/login', (req, res) => {
  fs.readFile('./database/users.json', 'utf8', (error, data) => {
    if (error) {
      console.error('Error reading users.json:', error);
      res.status(500).send('Error reading users.json');
    } else {
      const users = JSON.parse(data);
      const { username, password } = req.body;
      const user = users.find(u => u.username === username && u.password === password);

      if (user) {
        res.json({ userId: user.id });
      } else {
        res.status(400).json({ error: 'Invalid username or password' });
      }
    }
  });
});

// Existing code ...

app.post('/api/users/:userId/courses', (req, res) => {
  const userId = req.params.userId;
  const courseId = req.body.courseId;

  if (!userId || !courseId) {
    return res.status(400).json({ error: 'User ID and course ID are required.' });
  }

  fs.readFile('./database/users.json', 'utf8', (error, data) => {
    if (error) {
      console.error('Error reading users.json:', error);
      res.status(500).send('Error reading users.json');
    } else {
      const usersData = JSON.parse(data);
      const userIndex = usersData.findIndex(user => user.id.toString() === userId);

      if (userIndex === -1) {
        return res.status(404).json({ error: 'User not found.' });
      }

      if (!usersData[userIndex].courses) {
        usersData[userIndex].courses = [];
      }

      if (usersData[userIndex].courses.includes(courseId)) {
        return res.status(400).json({ error: 'Course already added to the user account.' });
      }

      usersData[userIndex].courses.push(courseId);
      fs.writeFile('./database/users.json', JSON.stringify(usersData, null, 2), (err) => {
        if (err) {
          console.error('Error writing users.json:', err);
          res.status(500).send('Error writing users.json');
        } else {
          res.status(201).json({ message: 'Course added to the user account.' });
        }
      });
    }
  });
});

// Existing code ...


app.post('/users/signup', (req, res) => {
  fs.readFile('./database/users.json', 'utf8', (error, data) => {
    if (error) {
      console.error('Error reading users.json:', error);
      res.status(500).send('Error reading users.json');
    } else {
      const users = JSON.parse(data);
      const { username, password } = req.body;

      if (users.find(u => u.username === username)) {
        res.status(400).json({ error: 'Username already in use' });
      } else {
        const newUser = {
          id: Date.now(), // Generate a unique ID based on the current timestamp
          username,
          password
        };

        users.push(newUser);
        fs.writeFile('./database/users.json', JSON.stringify(users, null, 2), (err) => {
          if (err) {
            console.error('Error writing users.json:', err);
            res.status(500).send('Error writing users.json');
          } else {
            res.json({ userId: newUser.id });
          }
        });
      }
    }
  });
});

// Do not remove this line. This allows the test suite to start
// multiple instances of your server on different ports
module.exports = app;
