let fetchedCourses = [];

function displayCourses(courses) {
  const container = document.getElementById('courses-container');
  container.innerHTML = ''; // Clear the current courses
  courses.forEach(course => {
    const courseElement = createCourseElement(course);
    container.appendChild(courseElement);
  });
}

function createCourseElement(course) {
  const courseContainer = document.createElement('div');
  courseContainer.classList.add('course');

  const courseCode = document.createElement('h3');
  courseCode.textContent = `${course.code} ${course.num}`;
  courseContainer.appendChild(courseCode);

  const courseName = document.createElement('h4');
  courseName.textContent = course.name;
  courseContainer.appendChild(courseName);

  const courseDescription = document.createElement('p');
  courseDescription.textContent = course.description.slice(0, 300) + '...';
  courseContainer.appendChild(courseDescription);

  const applyButton = document.createElement('button');
  applyButton.textContent = 'Apply';
  applyButton.classList.add('apply-button');
  applyButton.setAttribute('data-course-id', course.id); // Add course ID as a data attribute
  applyButton.addEventListener('click', event => {
    event.stopPropagation();
    addToUserCourses(parseInt(event.target.getAttribute('data-course-id'), 10)); // Pass course ID to the function
  });
  courseContainer.appendChild(applyButton);

  // Add icons container
  const iconsContainer = document.createElement('div');
  iconsContainer.classList.add('course-icons');
  courseContainer.appendChild(iconsContainer);

  // Add remote education icon
  const remoteIcon = document.createElement('img');
  remoteIcon.src = './images/Laptop.svg'; // Set the correct path to your remote icon file
  iconsContainer.appendChild(remoteIcon);

  // Add in-class education icon
  const inClassIcon = document.createElement('img');
  inClassIcon.src = './images/teacher.svg'; // Set the correct path to your in-class icon file
  iconsContainer.appendChild(inClassIcon);

  return courseContainer;
}

async function addToUserCourses(courseId) {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      alert('Please log in to add courses to your account.');
      return;
    }
  
    try {
      const response = await fetch('/api/users/' + userId + '/courses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ courseId })
      });
  
      if (response.ok) {
        alert('Course added to your account successfully.');
      } else {
        const { error } = await response.json();
        alert(`Error adding course: ${error}`);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error adding course. Please try again.');
    }
  }
  
async function fetchCourses() {
    try {
      const response = await fetch('/api/courses');
      fetchedCourses = await response.json();
      displayCourses(fetchedCourses);
      populateFilters(fetchedCourses);
  
      // Check for query string filters
      const queryParams = new URLSearchParams(window.location.search);
      const codeFilter = queryParams.get('code');
      const numFilter = queryParams.get('num');
  
      if (codeFilter || numFilter) {
        // Set and check the appropriate checkboxes
        if (codeFilter) {
          const codeCheckbox = document.querySelector(`#code-filters input[value="${codeFilter}"]`);
          if (codeCheckbox) {
            codeCheckbox.checked = true;
          }
        }
        if (numFilter) {
          const numCheckbox = document.querySelector(`#number-filters input[value="${numFilter}"]`);
          if (numCheckbox) {
            numCheckbox.checked = true;
          }
        }
  
        // Apply the filters
        applyFilters();
      }
  
    } catch (error) {
      console.error('Error fetching courses:', error);
    }
    }
  
fetchCourses();

function populateFilters(courses) {
    const codeSet = new Set();
    const numSet = new Set();
  
    courses.forEach(course => {
      codeSet.add(course.code);
      numSet.add(course.num);
    });
  
    const codeFilterGroup = document.getElementById('code-filters');
    const numFilterGroup = document.getElementById('number-filters');
  
    codeSet.forEach(code => {
      const filterOption = createFilterOption(code, 'code');
      codeFilterGroup.appendChild(filterOption);
    });
  
    numSet.forEach(number => {
      const filterOption = createFilterOption(number, 'number');
      numFilterGroup.appendChild(filterOption);
    });
  
    // Add event listeners to checkboxes
    codeFilterGroup.querySelectorAll('input[type="checkbox"]').forEach(input => {
      input.addEventListener('change', applyFilters);
    });
    numFilterGroup.querySelectorAll('input[type="checkbox"]').forEach(input => {
      input.addEventListener('change', applyFilters);
    });
}
  
  

function createFilterOption(value, name) {
    const filterOption = document.createElement('div');
    filterOption.classList.add('filter-option');
  
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = value;
    input.name = name;
    input.value = value;
    input.addEventListener('change', applyFilters); // Add the applyFilters event listener
  
    const label = document.createElement('label');
    label.htmlFor = value;
    label.textContent = value;
  
    filterOption.appendChild(input);
    filterOption.appendChild(label);
  
    return filterOption;
}
  

function applyFilters() {
    const codeFilters = Array.from(document.querySelectorAll('#code-filters input[type="checkbox"]'));
    const numFilters = Array.from(document.querySelectorAll('#number-filters input[type="checkbox"]'));
  
    const activeCodeFilters = codeFilters.filter(input => input.checked).map(input => input.value);
    const activeNumFilters = numFilters.filter(input => input.checked).map(input => input.value);
  
    const filteredCourses = fetchedCourses.filter(course => {
      const codeMatch = activeCodeFilters.length === 0 || activeCodeFilters.includes(course.code);
      const numMatch = activeNumFilters.length === 0 || activeNumFilters.includes(course.num);
  
      return codeMatch && numMatch;
    });
  
    displayCourses(filteredCourses);
}
  
  

document.addEventListener('DOMContentLoaded', () => {
    const expandableLabels = document.querySelectorAll('.expandable');
    expandableLabels.forEach((label) => {
      label.addEventListener('click', toggleFilterContent);
    });
    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', (event) => {
      filterCoursesBySearch(event.target.value);
    });
});
  
function toggleFilterContent(event) {
    const label = event.target;
    const content = label.nextElementSibling;
    label.classList.toggle('open');
    content.style.display = content.style.display === 'block' ? 'none' : 'block';
}

function filterCoursesBySearch(searchText) {
    const filteredCourses = fetchedCourses.filter(course => {
      const codeMatch = course.code.toLowerCase().startsWith(searchText.toLowerCase());
      const numMatch = course.num.toLowerCase().startsWith(searchText.toLowerCase());
      return codeMatch || numMatch;
    });
  
    displayCourses(filteredCourses);
}

document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = event.target.elements.username.value;
    const password = event.target.elements.password.value;
  
    try {
      const response = await fetch('/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });
  
      if (response.ok) {
        const { userId } = await response.json();
        localStorage.setItem('userId', userId.toString()); // Store the userId as a string
        alert('Logged in successfully.');
      } else {
        const { error } = await response.json();
        alert(`Error logging in: ${error}`);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error logging in. Please try again.');
    }
  });
  
  fetchCourses();