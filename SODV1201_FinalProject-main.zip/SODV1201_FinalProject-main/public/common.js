function updateHeader() {
    const userId = localStorage.getItem('userId');
    const accountBtn = document.getElementById('account-btn');
    const loginSignupBtns = document.getElementById('login-signup-btns');
  
    if (userId) {
      loginSignupBtns.style.display = 'none';
      accountBtn.style.display = 'block';
    } else {
      loginSignupBtns.style.display = 'block';
      accountBtn.style.display = 'none';
    }
  }
  
async function logout() {
    try {
      const response = await fetch('/users/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
  
      if (response.ok) {
        console.log('Logged out successfully');
        localStorage.removeItem('userId');
        updateHeader();
        window.location.href = '/'; // Redirect to the main page after successful logout
      } else {
        const { error } = await response.json();
        console.error(`Error logging out: ${error}`);
      }
    } catch (error) {
      console.error('Error:', error);
    }
}
  
function addLogoutListener() {
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', logout);
    }
}
  
updateHeader();
addLogoutListener();
  