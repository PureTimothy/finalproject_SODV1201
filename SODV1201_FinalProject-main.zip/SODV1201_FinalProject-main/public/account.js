document.addEventListener('DOMContentLoaded', () => {
    const userId = localStorage.getItem('userId');
    if (userId) {
        document.getElementById('user-id').textContent = userId;
    } else {
        // Redirect to the login page or show an error message
    }
});
